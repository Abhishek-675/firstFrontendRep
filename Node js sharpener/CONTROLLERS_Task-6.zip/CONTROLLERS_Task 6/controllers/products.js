const path = require('path');

const rootDir = require('../util/path');


exports.addProduct = (req, res, next) => {
    res.sendFile(path.join(rootDir, 'views', 'add-product.html'));
  }

exports.postAddProduct = (req, res, next) => {
    console.log(req.body);
    res.redirect('/');
  }


exports.contact_us = (req,res,next) => {
    res.sendFile(path.join(rootDir,'views','contact-us.html'));
}

exports.success = (req,res,next) => {
    res.sendFile(path.join(rootDir,'views','success.html'));
}


exports.shop = (req, res, next) => {
    res.sendFile(path.join(rootDir, 'views', 'shop.html'));
  }